---
title: "Designing for Multiple Screens in Android"
date: 2017-09-28T09:35:51-07:00
draft: false
---

Any app designer or developer knows that one of the most challenging parts to making a good app is making your UI compatible with the wide array of devices that your users are going to be viewing it on. And of course, Android is no exception.

There are a variety of steps Android takes to try to make your layouts compatible with any size, however for the best UI results you want to design and program with the array of different screens in mind. First, I want to introduce a few keywords that are often used when talking about device sizes:

*Screen size:*
Screen size is the physical size of the device, measured as the screen’s diagonal (measured in centimeters or inches). Android groups screen sizes into four generalized categories: small, normal, large, and extra-large.

*Screen density:*
Screen density is the quantity of pixels within a physical area of the screen (measured in dpi, or dots per inch). Android groups screen densities into size generalized categories: low, medium, high, extra-high, extra-extra-high and extra-extra-extra-high.

*Resolution:*
Resolution is the total number of pixels on a screen. When dealing with supporting multiple screens, we don’t want to work directly with resolution.
In this post, I am going to go through a few of the best practices for making size-responsive apps, and how to implement different layout designs.

## Achieve Density Independence
Density independence is important to achieve in your application. This means that the physical size of your elements remains the same across all screens. This needs to be taken into account because, say we have an image with a width of 300px, on a 160dpi screen this image would be around 2 inches wide, whereas on a 240dpi screen it would take up only 1¼ inches. That is, on lower density screens an element would look larger than on a higher density screen.

The Android system has two features that help your apps achieve density independence:

* The system scales dp units as appropriate for the current screen density
* The system scales drawable resources to the appropriate size, based on the current screen density, if necessary

One of the most basic steps you want to take to ensure density independence in your app is to specify all layout dimension values in density-independent pixels (dp units). A density-independent pixel is equivalent to one physical pixel on a 160dpi (or medium) screen. At runtime, the system handles scaling dp units based on the actual density of the screen in use, to make sure that the elements remain the same physical size on any device.

The second point above states that the system automatically scales bitmap drawables as appropriate. However, this can result in pixelation. To avoid this, you need to provide higher-resolution bitmaps for high-density screens, rather than relying on scaling of the images from the default medium screen size. How to do this is explained in subsequent sections of this post.


## Use "wrap_content" and "match_parent"
An easy way to make your layout responsive to different screen sizes is to use "wrap_content" and "match_parent" for the width and height of some view components. If you use "wrap_content", the width or height of the view is set to the minimum size necessary to fit the content within that view, while "match_parent" makes the component expand to match the size of its parent view.

By using the "wrap_content" and "match_parent" size values instead of hard-coded sizes, your views either use only the space required for that view or expand to fill the available space, respectively. For example, by making the paragraph in the layout below width: match_parent and height: wrap_content, the paragraph always takes up the full width of the screen and the button is located directly below the paragraph, automatically adapting for landscape or portrait view.

![portrait view with wrap_content and match_parent](../../images/post-designing-multiple-screens/post04.png)
![landscape view with wrap_content and match_parent](../../images/post-designing-multiple-screens/post05.png)

## Use RelativeLayout
Using RelativeLayout, as opposed to LinearLayout allows you to place elements relative to the edges or center of the screen specify your layout in terms of the special relationships between components. For example, we can set a button to stick to the rightmost side of the screen by setting layout_alignParentRight=”true”, as demonstrated in the images below.  

![portrait view with RelativeLayout](../../images/post-designing-multiple-screens/post06.png)
![landscape view with RelativeLayout](../../images/post-designing-multiple-screens/post07.png)

## Create Alternative Layouts
So far we have discussed how to make use of Android’s built-in features that attempt to automatically scale your app to fit an array of devices, and some of the easier practises to help make your layouts responsive. However, in most situations this process isn’t enough to make your app look exactly how you want on every device. To do this, we want to use alternative layouts and configuration qualifiers for different screen sizes.

### Use Configuration Qualifiers
Configuration qualifiers allow you to control how the system selects your alternative layouts and resources based on the current device screen. [You can see a table of all qualifiers here](https://developer.android.com/guide/topics/resources/providing-resources.html#AlternativeResources).

An example of where you would want to create alternative layouts is seen is many applications that implement multiple columns for information on larger screens, and a single column on smaller screens. To implement these two different layouts you could have two files: res/layout/main.xml for your default (single column) layout, and res/layout-large/main.xml for your secondary layout, and get different layouts for large and small screens as seen in the images below.

![portrait view with configuration qualifiers](../../images/post-designing-multiple-screens/post01.png)
![landscape view with configuration qualifiers](../../images/post-designing-multiple-screens/post02.png)

By using the “large” qualifier in the directory name of the second layout, this layout will be selected on devices with screens classified as large by Android.

To create these files, you simply create a new directory in our project’s “res/” directory by right-clicking on it, and selecting New > Directory. Name it using the format: <resource_name>-<qualifier> where:

* <resource_name> is the standard resource name such as layout, drawable, etc.
* <qualifier> is the configuration qualifier (from the above table) specifying the screen configuration for which you want to use these resources.

An example of a full list of resource directories for an app could look as follows:

![resource directories](../../images/post-designing-multiple-screens/post03.png)

### Use the Smallest Width Qualifier
Beginning with Android 3.2 (API level 13), you should use the sw<N>dp configuration qualifier to define the smallest available width required by your layout resources. For example, if your layout requires at least 600dp of screen width, you should place it in res/layout-sw600dp/. This means that devices whose smallest width is greater than or equal to 600dp will select the layout-sw600dp/main.xml layout, while smaller screens will select the layout/main.xml layout.

### Provide different bitmap drawables for different screen densities
As mentioned previously, by default, Android scales your bitmap drawables (.png, .jpg, and .gif files) so that they render at the appropriate physical size on each device. Similarly to how we used configuration qualifiers to specify layouts for different screen sizes, you should do the same to provide different images for different screen densities using the ldpi, mdpi, hdpi, xhdpi, xxhdpi, and xxxhdpi qualifiers.

## In Summary
So, lastly, how do you know that you need to change your app to fit different screen sizes? Generally, you want to test your app on each of the screen sizes and make sure on a small screen your layout completely fits, and on an extra-large screen you are making efficient use of the space you have. You also want to optimize for both landscape and portrait orientations, and make sure that your elements are set properly relative to each other that they are placed where they should be when you switch orientations.
