---
title: "Hosting a Static Website with Google Cloud Storage"
date: 2017-09-28T09:35:51-07:00
draft: false
---

Although dynamic websites are becoming increasingly popular and have numerous advantages, there are still many situations where static websites (or subdomains for static assets) make the most sense. This includes any website without constantly changing content or much user interaction, such as a personal portfolio or company landing page/website. Static websites are generally quicker and cheaper to develop and host, and there are even a number of static site generators that allow you to publish traditionally dynamic content (such as blog posts) easily. This blog, as well as the website at my base domain, are hosted using Google Cloud Storage, so this post will walk you through storing and hosting your static website step-by-step.

There are a number of cloud providers that offer free static website hosting, the main ones being Google Cloud Platform and Amazon Web Services. What you pay for when you use these services is data storage and transfer, however these costs are generally quite minimal. For example, storing 10GB on Google Cloud Storage will cost you $0.26/month. When you know the size of your website, you can use their pricing calculator to determine how much it will cost.

In this tutorial, we will be creating a project on Google Cloud Storage, uploading and sharing our website files, then pointing our domain to our bucket.

## Before you begin
Before you start this tutorial, you need to create an account with google cloud (cloud.google.com) and register a domain name. There are a number of places you can purchase your domain name, such as [Google Domains](http://domains.google.com), [GoDaddy](http://godaddy.com), and [Namecheap](http://namecheap.com).

## Setup
### 1. Create a project
First, go to the [cloud resource manager](http://console.cloud.google.com/cloud-resource-manager) and either create a new project or select an existing one. If you are creating a new project, you can name it whatever you want.

![manage resources](/images/post-hosting-with-cloud/01.png)
![create a new project](/images/post-hosting-with-cloud/02.png)

### 2. Enable billing
Next, you need to enable billing for your project. When you create a new project, you are either prompted to select which billing accounts you want to link to the project, or if you only have one billing account it is automatically linked. By clicking on Billing in the console menu, you can see your billing accounts, create new accounts, and view which projects are linked to which accounts.

![billing menu](/images/post-hosting-with-cloud/03.png)
![enable billing](/images/post-hosting-with-cloud/04.png)

### 3. Verify your domain
If you have purchased a Google domain and used the same account for your cloud storage, verification is automatic. Otherwise, you will need to use the [Google Webmaster Central verification](http://www.google.com/webmasters/verification). Select “Add a property” and make sure you are verifying your domain (for example, amandahehr.com) and not a site on the domain (such as www.amandahehr.com). Once you click continue, it will give you step-by-step instructions to verify your domain.

![domain verification](/images/post-hosting-with-cloud/05.png)

## Store your website
Once the setup is complete, we will first store our website files in the project we created. Starting from the [console](http://console.cloud.google.com), we will select Storage from the menu to take us to our Buckets.

![storage menu](/images/post-hosting-with-cloud/06.png)  
![storage browser](/images/post-hosting-with-cloud/07.png)

From here, you want to select “Create bucket” and create a bucket with your website address as the bucket name. Select Multi-Regional as the default storage class and click “Create”.

![create a bucket](/images/post-hosting-with-cloud/08.png)  

From here, you want to upload all of your website files and folders. You can do this by dragging your files onto the screen, or selecting “Upload Files” or “Upload Folder”. You should then see all of your website’s files and folders inside your bucket.

![upload files](/images/post-hosting-with-cloud/09.png)

Lastly, we need to publicly share every file we uploaded. We can do this by checking the “Share publicly” boxes for each file or mass-selecting each file and clicking the “Share Publicly” icon on the top menu. If your files are organized into multiple folders as mine are, you will need to go into each folder and do this for every file.

Now you should be able to click on the “Public Link” hyperlink next to the “Share publicly” check box on your main html file (index.html) and see your website as it will be once it is hosted. Now all you need to do is point your domain to the bucket you created.

## Pointing your domain
All you need to do to point your domain to your cloud storage bucket is set up a CNAME alias that points to c.storage.googleapis.com. To do this, go to your account on the website you purchased your domain, go to manage your domain and configure DNS. This process may be slightly different for different websites, so you may need to look up how to configure the DNS for your particular service if it is not straightforward.

### 1. Create CNAME alias
The interface will look slightly different depending on who you bought your domain from, but it should be similar. Under Custom Resource Records, at a CNAME with “www” to point to c.storage.googleapis.com..

![CNAME record](/images/post-hosting-with-cloud/10.png)

This will direct your URL (www.yourwebsite.com) to point to your cloud storage bucket of the same name. If you want to direct a different/additional site on your domain to a bucket, such as blog.yourwebsite.com, you simply put “blog” into your CNAME record instead of “www”, and make sure your bucket name is also blog.yourwebsite.com.

### 2. Set up a synthetic record
If you would like your domain to also point to your bucket (for example, yourwebsite.com as well as www.yourwebsite.com) you want to set up a subdomain forward to forward @ to your www address (ex. http://www.amandahehr.com).

![synthetic record](/images/post-hosting-with-cloud/11.png)

### 3. Assign your index and error pages
The last step is to tell your bucket which html pages to serve as your main page and 404 (not found) page. To do this, go back to your Cloud Platform Storage Browser where you can see your Buckets, and from the menu to the right of your bucket select “Edit website configuration”.

![assign index and error pages](/images/post-hosting-with-cloud/12.png)

Put in the filenames for your main page and 404 page and click save. Depending on your browser and internet speed, you should now be able to navigate to your URL and see your website up and running. Note that on some browsers and public internet the changes you upload may take some time to be viewable.  
